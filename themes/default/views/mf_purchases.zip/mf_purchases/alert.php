<div aria-hidden="false" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="posModal" 
data-easein="flipYIn" class="modal posModal in" style="display: block; padding-left: 17px;">
<div class="modal-dialog">

    <div class="modal-content">

        <div class="modal-header">

            <button type="button" onclick="hide()"  class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i>

            </button>

            <h4 class="modal-title" id="myModalLabel"> <?php echo $error_alert ; ?></h4>

        </div>


</div>
</div>

